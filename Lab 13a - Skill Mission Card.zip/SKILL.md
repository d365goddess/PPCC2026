---
name: missioncard
description: Builds a Top Gun-style mission card (a downloadable HTML file) for one flight plan. Use when the pilot asks for a mission card, briefing card, or kneeboard card for a flight plan ID like FLP-1000B6W5.
---
When this skill is activated:

1. Get the flight plan ID (like FLP-1000B6W5). If the pilot didn't give one, ask for it.
2. Look up the flight plan and the Fighter Jet record linked by its Aircraft lookup with the Dataverse MCP Server.
3. Write the flight details to `/tmp/flight.json` with Python (`json.dump`), not a shell command, using exactly the field names in the table below. Take every value from the Dataverse MCP Server only. Copy the flight date and time exactly as it returns it; don't convert time zones or compare it with other sources.
4. Run:
   ```
   python scripts/build_card.py --input /tmp/flight.json --output /tmp/mission-card-<flight ID>.html
   ```
   The script creates two files: the animated card `/tmp/mission-card-<flight ID>.html` and a preview image `/tmp/mission-card-<flight ID>.png`.
5. Show the PNG in the chat as an image, and return the HTML file as a download, with one short line in your GOOSE voice. Tell them the image is a preview, and to download the HTML file and open it in a browser for the full animated card.
6. Then follow the **calendarinvite** skill for the same flight. It uses the same `/tmp/flight.json`.

## Flight details

| Field | Where it comes from |
| --- | --- |
| flight_id | Flight Plan: Record ID (rsm_recordid) |
| flight_plan_name | Flight Plan: Flight Plan Name (rsm_flightplanname) |
| pilot_name | Flight Plan: Pilot Name (rsm_pilotname). Keep any "nickname" in quotes |
| flight_datetime | Flight Plan: Flight Date/Time (rsm_flightdateandtime), copied exactly as Dataverse returns it, including any Z or offset, in ISO format like 2027-01-06T09:15:00. Don't convert time zones; the script does that |
| duration_minutes | Flight Plan: Est. Duration (Minutes) (rsm_estimateddurationminutes) |
| mission_type, mission_objective | Flight Plan: Mission Type, Mission Objective |
| clearance_status | Flight Plan: Clearance Status, as text: Approved, Pending, or Denied |
| fuel_gallons | Flight Plan: Fuel Requirement (Gallons) |
| aircraft_name | Fighter Jet: Jet Name (rsm_jetname), the jet linked by the flight plan's Aircraft lookup |
| max_speed_mph, thrust_lbf, max_takeoff_lb, fuel_capacity_lb | Fighter Jet: Max Speed (MPH), Thrust, Max Takeoff Weight (lbs), Fuel Capacity (lbs) |
| prime_contractor, engine | Fighter Jet: Prime Contractor, Engine Details |

Example `/tmp/flight.json`:

```json
{
  "flight_id": "FLP-1000B6W5",
  "flight_plan_name": "Alpha Guardian",
  "pilot_name": "Amelia \"Blaze\" Rivers",
  "flight_datetime": "2027-01-06T09:15:00",
  "duration_minutes": 120,
  "mission_type": "Patrol Mission",
  "mission_objective": "Monitor restricted airspace",
  "clearance_status": "Approved",
  "fuel_gallons": 1060,
  "aircraft_name": "F-35A Lightning II",
  "max_speed_mph": 1200,
  "thrust_lbf": 43000,
  "max_takeoff_lb": 70000,
  "fuel_capacity_lb": 18498,
  "prime_contractor": "Lockheed Martin",
  "engine": "One Pratt & Whitney F135-PW-100 turbofan engine"
}
```

## Rules

- Never edit the script or the template, and never write the card HTML yourself. The script makes every card identical.
- Never use image generation for the card.
- Never invent values. If a field is empty in Dataverse, use an empty string (or 0 for numbers) and mention it.
- If the script reports an error, fix the values in `/tmp/flight.json` and run it again.
