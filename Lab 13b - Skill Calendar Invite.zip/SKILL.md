---
name: calendarinvite
description: Creates a calendar invite (.ics file) and a styled email for one flight plan and delivers them the way the pilot wants - added to their Outlook calendar, emailed, or as downloads. Use after the missioncard skill, or when the pilot asks to put a flight on their calendar or email it.
---
When this skill is activated:

1. Make sure `/tmp/flight.json` exists with the flight details (the missioncard skill writes it). If it doesn't, look up the flight plan and its linked Fighter Jet record with the Dataverse MCP Server and write the file with Python (`json.dump`), not a shell command, using the field names in the table below. Copy the flight date and time exactly as Dataverse returns it.
2. Ask the pilot how they want it, unless they already said: on their calendar, by email, or as downloads. More than one is fine.
3. If the pilot wants the event on their calendar, add it first (step 4), so the email can say so. Then run (add `--on-calendar` only if the event is on their calendar):
   ```
   python scripts/build_dispatch.py --input /tmp/flight.json --outdir /tmp
   ```
   It creates `/tmp/mission-<flight ID>.ics`, `/tmp/mission-email-<flight ID>.html`, and `/tmp/mission-event-<flight ID>.html` (the styled event details), and prints the fields for an Outlook calendar event.
4. Deliver:
   - **Calendar:** use the Office 365 Outlook **Create event (V4)** tool with the printed fields (Subject, Start time, End time, Time zone, Reminder, Show as). Body: the contents of the `mission-event-<flight ID>.html` file the code created, exactly as generated, as HTML. Use the pilot's default calendar.
   - **Email:** use the Office 365 Outlook **Send an email (V2)** tool. Send it to the signed-in pilot's own email address. Subject: `Mission card: <flight plan name> (<flight ID>)`. Body: the contents of `/tmp/mission-email-<flight ID>.html`, exactly as generated, as HTML. Importance: Normal. Attach the mission card HTML if the script said it found one. Attach the .ics file only if you did **not** add the event to their calendar (otherwise it would invite a duplicate). If the tool won't take attachments, send the email without them and offer the files as downloads.
   - **Downloads:** return the .ics file (and the mission card, if it exists) in the chat. Opening the .ics adds the flight to any calendar app.
5. Confirm what happened in one short line in your GOOSE voice.

## Flight details

| Field | Where it comes from |
| --- | --- |
| flight_id | Flight Plan: Record ID (rsm_recordid) |
| flight_plan_name | Flight Plan: Flight Plan Name (rsm_flightplanname) |
| pilot_name | Flight Plan: Pilot Name (rsm_pilotname). Keep any "nickname" in quotes |
| flight_datetime | Flight Plan: Flight Date/Time (rsm_flightdateandtime), copied exactly as Dataverse returns it, including any Z or offset, in ISO format like 2027-01-06T09:15:00. Don't convert time zones; the script does that |
| duration_minutes | Flight Plan: Est. Duration (Minutes) (rsm_estimateddurationminutes) |
| mission_type, mission_objective | Flight Plan: Mission Type, Mission Objective |
| clearance_status | Flight Plan: Clearance Status, as text: Approved, Pending, or Denied |
| fuel_gallons | Flight Plan: Fuel Requirement (Gallons) |
| aircraft_name | Fighter Jet: Jet Name (rsm_jetname), the jet linked by the flight plan's Aircraft lookup |
| max_speed_mph, thrust_lbf, max_takeoff_lb, fuel_capacity_lb | Fighter Jet: Max Speed (MPH), Thrust, Max Takeoff Weight (lbs), Fuel Capacity (lbs) |
| prime_contractor, engine | Fighter Jet: Prime Contractor, Engine Details |

## Rules

- Only say an event was created or an email was sent if the tool reported success.
- Never edit the script or the email template, and never write the email HTML yourself. It's built with tables and inline styles so it displays correctly in Outlook.
- Flight times are US Pacific. The .ics file stores them in UTC so every calendar shows the right local time.
